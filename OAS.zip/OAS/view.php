<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>View Attendance</title>
    <link rel="stylesheet" href="Sview.css?v=?php echo time();?">
  </head>
  <body>
    <h1>View Attendance</h1><hr>
  <input type="button" style="background: #2691d9; margin-left: 10%; height: 60px; width:120px; font-size: 24px" value="Back" onclick="history.back()">
  <?php include "config.php" ?>
    <br>
    <form class="con" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
      <div class="Dep"><label>Department</label>
        <select name="Dep"required>
          <?php
            $sql = "SELECT * FROM dep";
            $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
            while($row = mysqli_fetch_assoc($result)){
           ?>
          <option><?php echo $row['Department'] ?></option>
        <?php } ?>
        </select>
      </div>
      <br>
      <div class="Sem"><label>Semester</label>
        <select name="Sem" required>
          <?php
            $sql = "SELECT * FROM sem";
            $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
            while($row = mysqli_fetch_assoc($result)){
           ?>
          <option><?php echo $row['semester'] ?></option>
        <?php } ?>
        </select>
      </div>
      <br>
      <label>Subject</label>
      <input type="text" name="Subject" required>
      <br>
      <br>
      <div class="date"><label>Date</label>
        <input type="date" name="Date" placeholder="dd-mm-yyyy;" required>
      </div>
      <br>
      <div class="Get">
        <input type="submit" name="Get" >
      </div>
    </form>
    <?php

    if(isset($_POST['Get'])){
      $department = $_POST['Dep'];
      $semester = $_POST['Sem'];
      $subject = $_POST['Subject'];
      $D = $_POST['Date'];
      $date = date("d-m-y",strtotime($D));
      $teacher = $_GET['user'];
     ?>
    <br>
    <br>
    <div class="Table">
    <h3>Attendance of <?php echo "$department"; ?>, <?php echo "$semester"; ?> semester</h3>
    <h3><?php echo "$subject"; ?></h3>
    <h3><?php echo "$date"; ?></h3>
    <hr>
    <?php
    $sqlV = "SELECT attend.roll, attend.name, attend.attendance FROM attend WHERE attend.department = '$department' AND attend.semester = '$semester' AND attend.date = '$date' AND attend.subject = '$subject' AND attend.teacher = '$teacher' ORDER BY attend.roll ASC";
    $resultV = mysqli_query($conn, $sqlV) or die("Query Faild.");
    if(mysqli_num_rows($resultV)>0){
    ?>
    <table cellpadding="7px">
      <thead>
        <th>Roll</th>
        <th>Name</th>
        <th>Attendance</th>
      </thead>
      <tbody>
        <?php
        while($rowV = mysqli_fetch_assoc($resultV)){
         ?>
        <tr>
          <td><?php echo $rowV['roll']; ?></td>
          <td><?php echo $rowV['name']; ?></td>
          <td><?php echo $rowV['attendance']; ?></td>
        </tr>
        <tr>
        <?php } ?>
      </tbody>
      </table>
    <?php }else {
      die("<h3>No records found.</h3>");
    } ?>
    <?php }else {
      die();
    } ?>
    </div><br><br><br><br>
  </body>
</html>
