<?php include "config.php" ?>
<?php

session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Edit Attendance</title>
    <link rel="stylesheet" href="Sedit.css">
  </head>
  <body>
    <h1>Edit Attendance</h1><hr>
      <input type="button" style="background: #2691d9; margin-left: 10%; height: 60px; width:120px; font-size: 24px" value="Back" onclick="history.back()">
    <form class="con" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
      <div class="Dep"><label>Department</label>
        <select name="Dep"required>
          <?php
            $sql = "SELECT * FROM dep";
            $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
            while($row = mysqli_fetch_assoc($result)){
           ?>
          <option><?php echo $row['Department'] ?></option>
        <?php } ?>
        </select>
      </div>
      <br>
      <div class="Sem"><label>Semester</label>
        <select name="Sem" required>
          <?php
            $sql = "SELECT * FROM sem";
            $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
            while($row = mysqli_fetch_assoc($result)){
           ?>
          <option><?php echo $row['semester'] ?></option>
        <?php } ?>
        </select>
      </div>
      <br>
      <label>Subject</label>
      <input type="text" name="Subject" required>
      <br>
      <br>
      <div class="date"><label>Date</label>
        <input type="date" name="Date" required>
      </div>
      <br>
      <br>
      <div class="Roll"><label>Roll No.</label>
        <input type="number" name="roll" required>
      </div>
      <br>
      <div class="Get">
        <input type="submit" name="Get" value="Get">
      </div>
    </form>
    <?php

    if(isset($_POST['Get'])){
      $use = $_GET['user'];
     $department = $_POST['Dep'];
     $semester = $_POST['Sem'];
     $subject = $_POST['Subject'];
     $D = $_POST['Date'];
     $date = date("d-m-y",strtotime($D));
     $roll = $_POST['roll'];
     $sqlE = "SELECT * FROM attend WHERE attend.department = '$department' AND attend.semester = '$semester' AND attend.roll = '$roll' AND attend.date = '$date' AND attend.subject = '$subject' AND attend.teacher = '$use'";
     $resultE = mysqli_query($conn, $sqlE) or die ("Query Unsuccessful.");
     if(mysqli_num_rows($resultE)>0){
       $rowE = mysqli_fetch_assoc($resultE)
     ?>
    <hr>
    <form class="" action="Aedit.php" method="post">
      <table cellpadding="7px">
        <h3>Attendance of <?php echo "$department"; ?>,<?php echo "<br> $semester semester."; ?></h3>
        <h3><?php echo "$subject"; ?></h3>
        <h3><?php echo "$date"; ?></h3>
        <thead>
          <th>Roll</th>
          <th>Name</th>
          <th>Attendance</th>
          <th hidden>Date</th>
          <th hidden>Subject</th>
          <th hidden>Department</th>
          <th hidden>Semester</th>
        </thead>
        <tbody>
          <tr>
            <td><input type="text" name="Eroll" class="Roll" maxlength="1" size="1" value="<?php echo $rowE['roll']?> " readonly></input></td>
            <td><input type="text" name="Ename" class="Name" maxlength="12" size="12" value="<?php echo $rowE['name'] ?>" readonly></input</td>
            <td><select class="Attendence" name="Atten">
              <option value="Present">Present</option>
              <option value="Absent">Absent</option>
            </select>
            </td>
            <td hidden><input name="Edate" type="text"readonly value="<?php echo "$date"; ?>"></input></td>
            <td hidden><input name="Esubject" type="text"readonly value="<?php echo "$subject"; ?>"></input></td>
            <td hidden><input name="Edepartment" type="text"readonly value="<?php echo "$department"; ?>"></input></td>
            <td hidden><input name="Esemester" type="text"readonly value="<?php echo "$semester"; ?>"></input></td>
          </tr>

        </tbody>
        </table>
        <input type="submit" name="save" value="Save">
    </form>
  <?php }else {
    die("<h3>No Data Found.<h3>");
  } ?>
<?php }else {
  die();
} ?>
    <br><br>
  </body>
</html>
