<?php



 $conn = mysqli_connect("localhost","root","","oad") or die("connection Failed".mysqli_connect_error());

 ?>
