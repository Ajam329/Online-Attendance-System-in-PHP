<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Home</title>
    <link rel="stylesheet" href="Shomepage.css?v=?php echo time();?>">
  </head>
  <body>
    <h1>Global Institue Of Science And Technology</h1>
    <h3>Attendance site</h3>
    <div class="cont">
    <a href="login.php">
      <button style="margin-left: 25%; margin-top: 10%;"><span>Teacher's Login here</span></button>
    </a>
    <a href="view.php">
      <button style="margin-left: 10%; margin-top: 10%;"><span>Student's Attendance</span></button>
    </a>
  </div>
  </body>
</html>
