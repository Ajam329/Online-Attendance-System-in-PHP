<?php
include "config.php";
 ?>
<?php

session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Creat & Take Attendance</title>
    <link rel="stylesheet" href="Screat.css?v=?php echo time();?">
    <link rel="login" href="login_process.php">
  </head>
  <body>
    <h1>Creat & Take Attendance</h1><hr>
    <input type="button" style="background: #2691d9; margin-left: 10%; height: 60px; width:120px; font-size: 24px" value="Back" onclick="history.back()">
    <br>
    <form class="con" action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
      <br>
      <div class="Dep"><label>Department</label>
        <select name="Dep" required>
          <?php
            $sql = "SELECT * FROM dep";
            $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
            while($row = mysqli_fetch_assoc($result)){
           ?>
          <option><?php echo $row['Department'] ?></option>
        <?php } ?>
        </select>
      </div>
      <br>
      <div class="Sem"><label>Semester</label>
        <select name="Sem" required>
          <?php
            $sql = "SELECT * FROM sem";
            $result = mysqli_query($conn, $sql) or die("Query Unsuccessful.");
            while($row = mysqli_fetch_assoc($result)){
           ?>
          <option><?php echo $row['semester'] ?></option>
        <?php } ?>
        </select>
      </div>
      <br>
      <div class="Sub">
        <label>Subject</label>
        <input type="text" name="Subject"required>
      </div>
      <br>
      <div class="creat">
        <input type="submit" name="Creat" value="CREAT">
      </div>
      <br>
    </form>
    <br><br>
    <?php
    if(isset($_POST['Creat'])){

      $department = $_POST['Dep'];
      $semester = $_POST['Sem'];
      $subject = $_POST['Subject'];
      $date = date("d-m-y");
      $teacher = $_GET['user'];
?>
    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
    <div class="Table">
      <br>
      <br>
    <h3>Attendance form for <?php echo "$department"; ?>,<?php echo "<br> $semester semester."; ?></h3>
    <h3><?php echo "$subject"; ?></h3>
    <h3><?php echo "$date"; ?></h3>
    <hr>
    <?php
    $sqlA = "SELECT stu.Roll, stu.Name FROM stu INNER JOIN dep ON stu.depa = dep.Did INNER JOIN sem ON stu.seme = sem.Sid WHERE dep.Department = '$department'AND sem.semester = '$semester' ORDER BY stu.Roll ASC";
    $resultA = mysqli_query($conn, $sqlA) or die("Query Unsuccessful.");
    if(mysqli_num_rows($resultA)>0){
     ?>
    <table cellpadding="7px">
      <thead>
        <th>Roll</th>
        <th>Name</th>
        <th>Attendance</th>
        <th hidden>Date</th>
        <th hidden>Subject</th>
        <th hidden>Department</th>
        <th hidden>Semester</th>
        <th hidden>Teacher</th>
      </thead>
      <tbody>
        <?php
          while($rowA = mysqli_fetch_assoc($resultA)){

         ?>
        <tr>
          <td><input type="text" name="ARoll[]" class="Roll" maxlength="1" size="1" value="<?php echo $rowA['Roll']?> " readonly></input></td>
          <td><input type="text" name="AName[]" class="Name" maxlength="12" size="12" value="<?php echo $rowA['Name'] ?>" readonly></input</td>
          <td><select class="Attendence" name="Atten[]">
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
          </select>
          </td>
          <td><input name="ADate[]" type="text"readonly hidden value="<?php echo "$date"; ?>"></input></td>
          <td><input name="ASubject[]" type="text"readonly hidden value="<?php echo "$subject"; ?>"></input></td>
          <td><input name="ADepartment[]" type="text"readonly hidden value="<?php echo "$department"; ?>"></input></td>
          <td><input name="ASemester[]" type="text"readonly hidden value="<?php echo "$semester"; ?>"></input></td>
          <td><input name="ATeacher[]" type="text"readonly hidden value="<?php echo "$teacher"; ?>"></input></td>
        </tr>
      <?php } ?>

      </tbody>
      </table>
    <?php }else {
      die(" <h3>No Records of Students Found<h3>");
    } ?>
    </div><br>
    <input type="submit" name="save" value="Save" style="margin-left: 40%">
      <br>
      <br>
    <?php } ?>
    </form>
    <?php

    if(isset($_POST['save'])){

       $Aroll = $_POST['ARoll'];
       $Aname = $_POST['AName'];
       $atten = $_POST['Atten'];
       $Adepartment = $_POST['ADepartment'];
       $Adate = $_POST['ADate'];
       $Asemester = $_POST['ASemester'];
       $Asubject = $_POST['ASubject'];
       $Ateacher = $_POST['ATeacher'];

       foreach ($Aroll as $key => $value) {
         $save = "INSERT INTO attend(date,name,roll,semester,attendance,teacher,subject,department)VALUES('".$Adate[$key]."','".$Aname[$key]."','".$value."','".$Asemester[$key]."','".$atten[$key]."','".$Ateacher[$key]."','".$Asubject[$key]."','".$Adepartment[$key]."')";
         $result_A = mysqli_query($conn, $save);

      }

     ?>
  <?php }else {

        die(); } ?>
    <br><br><a href="teacherspc.php"><button style="background: #2691d9;margin-left: 80%">Back</button></a>
    <br><br><br>
  </body>
</html>
