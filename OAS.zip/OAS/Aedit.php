
<?php

session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}
?>
<?php
include "config.php";
 $E_department = $_POST['Edepartment'];
 $E_semester = $_POST['Esemester'];
 $E_subject = $_POST['Esubject'];
 $E_date = $_POST['Edate'];
 $E_roll = $_POST['Eroll'];
 $atten = $_POST['Atten'];
$sqlE_A = "UPDATE attend SET attend.attendance = '$atten' WHERE attend.roll = '$E_roll' AND attend.date = '$E_date' AND attend.semester = '$E_semester' AND attend.subject = '$E_subject' AND attend.department = '$E_department'";
$resultE_A = mysqli_query($conn, $sqlE_A);
header("Location: view.php")
 ?>
