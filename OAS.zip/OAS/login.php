<?php
include "config.php";
 ?>
<?php

session_start();
if(isset($_SESSION["username"])){
  header("Location: teacherspc.php");
}

 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login</title>
    <link rel="stylesheet" href="Slogin.css">
  </head>
  <body>
    <a href="homepage.php"><button style="background: #2691d9; margin-top: 14%; margin-left: 38%; font-size: 24px;">Home</button></a>
    <div class="center">
      <h1>Login</h1>
      <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post">
        <div class="txt_field">
          <input type="text" id="user" name="user" required>
          <label>Username</label>
          <span></span>
        </div>
        <div class="txt_field">
          <input type="password" id="pass" name="pass" required>
          <label>Password</label>
          <span></span>
          <div class="log">
            <input type="submit" name="Login" value="Login">
            <br><br>
          </div>
        </div>
      </form>
      <?php

      if(isset($_POST['Login'])){
        $username = mysqli_real_escape_string($conn,$_POST['user']);
        $password = $_POST['pass'];

        $sql = "SELECT username FROM teachers WHERE username = '$username' AND password = '$password'";
        $result = mysqli_query($conn, $sql) or die("Query Failed.");
        if(mysqli_num_rows($result)>0){
          while($row = mysqli_fetch_assoc($result)){
            session_start();
            $_SESSION["username"] = $row['username'];
            header("Location: teacherspc.php?user={$row['username']}");
          }
        }else {
          echo '<h3>Username and Password are not same!!<h3>';
        }

      }


       ?>
    </div>

  </body>
</html>
