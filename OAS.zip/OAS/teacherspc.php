<?php
include "config.php";
 ?>
<?php $use = $_GET['user'];?>
<?php

session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}else {
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Username</title>
      <link rel="stylesheet" href="Steacherspc.css?v=?php echo time();?">
  </head>
  <body>
    <h1>Global Institue Of Science And Technology</h1>
    <h3>Welcome, <?php echo "$use" ?>!</h3>
    <div class="con"style="padding: 0 80px;box-sizing: border-box;border: 1px solid;width: 50%;margin-left: auto;margin-right: auto;background-color: rgba(0, 0, 0, 0.2)">
      <?php echo '<a href="creat.php?user=' . $use . '">'; ?><button style="margin-right: 50px; font-size: 26px; margin-right: 5%;"><span>Creat & Take Attendance</span></button></a>
      <?php echo '<a href="edit.php?user=' . $use . '">'; ?><button style="margin-right: 50px;"><span>Edit Attendance</span></button></a>
      <?php echo '<a href="view.php?user=' . $use . '">'; ?><button style="margin-right: 50px;"><span>View Attendance</span></button></a>
    </div>
    <br><br><br><br>
      <a href="logout.php"><button style="background: #2691d9; margin-top: 3%; margin-left: 34%;">Logout</button></a>
</html>
<?php } ?>
