-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 01, 2021 at 05:37 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oad`
--

-- --------------------------------------------------------

--
-- Table structure for table `attend`
--

CREATE TABLE `attend` (
  `Aid` int(250) NOT NULL,
  `date` varchar(100) NOT NULL,
  `name` varchar(25) NOT NULL,
  `roll` int(100) NOT NULL,
  `semester` int(10) NOT NULL,
  `attendance` varchar(10) NOT NULL DEFAULT 'Absent',
  `teacher` varchar(25) NOT NULL,
  `subject` varchar(25) NOT NULL,
  `department` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attend`
--

INSERT INTO `attend` (`Aid`, `date`, `name`, `roll`, `semester`, `attendance`, `teacher`, `subject`, `department`) VALUES
(63, '10-08-21', 'Md. Ajam', 1, 6, 'Present', 'Md. Ajam', 'Maths', 'Computer Science & Technology'),
(64, '10-08-21', 'Adrija Maji', 2, 6, 'Absent', 'Md. Ajam', 'Maths', 'Computer Science & Technology'),
(65, '10-08-21', 'Santu Sahoo', 3, 6, 'Present', 'Md. Ajam', 'Maths', 'Computer Science & Technology'),
(66, '10-08-21', 'Susobhan Sahoo', 4, 6, 'Present', 'Md. Ajam', 'Maths', 'Computer Science & Technology'),
(67, '10-08-21', 'Puja Bhattacharya', 5, 6, 'Present', 'Md. Ajam', 'Maths', 'Computer Science & Technology'),
(68, '10-08-21', 'Sourav Khatua', 6, 6, 'Present', 'Md. Ajam', 'Maths', 'Computer Science & Technology'),
(69, '10-08-21', 'Subhendu Mandal', 7, 6, 'Present', 'Md. Ajam', 'Maths', 'Computer Science & Technology'),
(70, '10-08-21', 'Gurav Jha', 8, 6, 'Absent', 'Md. Ajam', 'Maths', 'Computer Science & Technology');

-- --------------------------------------------------------

--
-- Table structure for table `dep`
--

CREATE TABLE `dep` (
  `Did` int(10) NOT NULL,
  `Department` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dep`
--

INSERT INTO `dep` (`Did`, `Department`) VALUES
(1, 'Mechanical '),
(2, 'Civil'),
(3, 'Electrical'),
(4, 'Computer Science & Technology');

-- --------------------------------------------------------

--
-- Table structure for table `sem`
--

CREATE TABLE `sem` (
  `Sid` int(11) NOT NULL,
  `semester` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sem`
--

INSERT INTO `sem` (`Sid`, `semester`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5),
(6, 6);

-- --------------------------------------------------------

--
-- Table structure for table `stu`
--

CREATE TABLE `stu` (
  `Roll` int(100) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `S_no` bigint(255) NOT NULL,
  `seme` int(10) NOT NULL,
  `depa` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stu`
--

INSERT INTO `stu` (`Roll`, `Name`, `S_no`, `seme`, `depa`) VALUES
(1, 'Md. Ajam', 17, 6, 4),
(2, 'Adrija Maji', 18, 6, 4),
(3, 'Santu Sahoo', 19, 6, 4),
(4, 'Susobhan Sahoo', 20, 6, 4),
(5, 'Puja Bhattacharya', 21, 6, 4),
(6, 'Sourav Khatua', 22, 6, 4),
(7, 'Subhendu Mandal', 23, 6, 4),
(8, 'Gurav Jha', 24, 6, 4);

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `username`, `password`) VALUES
(1, 'Md. Ajam', 'itsmemario');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attend`
--
ALTER TABLE `attend`
  ADD PRIMARY KEY (`Aid`);

--
-- Indexes for table `dep`
--
ALTER TABLE `dep`
  ADD PRIMARY KEY (`Did`);

--
-- Indexes for table `sem`
--
ALTER TABLE `sem`
  ADD PRIMARY KEY (`Sid`);

--
-- Indexes for table `stu`
--
ALTER TABLE `stu`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attend`
--
ALTER TABLE `attend`
  MODIFY `Aid` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `dep`
--
ALTER TABLE `dep`
  MODIFY `Did` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sem`
--
ALTER TABLE `sem`
  MODIFY `Sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `stu`
--
ALTER TABLE `stu`
  MODIFY `S_no` bigint(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
